﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Net;
using System.Net.Sockets;


namespace WindowsFormsApplication1
{
    public partial class Consultas : Form
    {

        Socket server;

        public Consultas()
        {
            InitializeComponent();
            //Creamos un IPEndPoint con el ip del servidor y puerto del servidor 
            //al que deseamos conectarnos
            IPAddress direc = IPAddress.Parse("192.168.56.102");
            IPEndPoint ipep = new IPEndPoint(direc, 9070);


            //Creamos el socket 
            server = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
            try
            {
                server.Connect(ipep);//Intentamos conectar el socket
                this.BackColor = Color.Green;
            }


            catch (SocketException)
            {
                //Si hay excepcion imprimimos error y salimos del programa con return 
                MessageBox.Show("No he podido conectar con el servidor");
                return;
            }
        }

        //Consulta el ganador que ganó en menor tiempo
        private void radioButton1_Click_1(object sender, EventArgs e)
        {
            // Quiere realizar la consulta escogida
            string mensaje = "3/";
            // Enviamos al servidor el user tecleado 
            byte[] msg = System.Text.Encoding.ASCII.GetBytes(mensaje);
            server.Send(msg);

            //Recibimos la respuesta del servidor
            byte[] msg2 = new byte[80];
            server.Receive(msg2);
            mensaje = Encoding.ASCII.GetString(msg2).Split('\0')[0];
            MessageBox.Show(mensaje);
        }

        //Consulta el menor tiempo en ganar del usuario dado
        private void radioButton2_Click(object sender, EventArgs e)
        {
                string mensaje = "4/" + textBox1.Text;
                // Enviamos al servidor el user tecleado 
                byte[] msg = System.Text.Encoding.ASCII.GetBytes(mensaje);
                server.Send(msg);

                //Recibimos la respuesta del servidor
                byte[] msg2 = new byte[80];
                server.Receive(msg2);
                mensaje = Encoding.ASCII.GetString(msg2).Split('\0')[0];
                MessageBox.Show(mensaje);
        }

        //Botón Volver
        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            // Quiere saber el número de peticiones realizadas por el servidor
            string mensaje = "7/";
            byte[] msg = System.Text.Encoding.ASCII.GetBytes(mensaje);
            server.Send(msg);

            //Recibimos la respuesta del servidor
            byte[] msg2 = new byte[80];
            server.Receive(msg2);
            mensaje = Encoding.ASCII.GetString(msg2).Split('\0')[0];
            label3.Text = mensaje;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            string mensaje = "6/";
            byte[] msg = System.Text.Encoding.ASCII.GetBytes(mensaje);
            server.Send(msg);

            //Recibimos la respuesta del servidor
            byte[] msg2 = new byte[80];
            server.Receive(msg2);
            mensaje = Encoding.ASCII.GetString(msg2).Split('\0')[0];


            string[] trozos = mensaje.Split('/');
            int i = 0;
            int n;
            dataGridView1.Rows.Clear();
            dataGridView1.Refresh();

            if (trozos[i] == "0")
            {
                MessageBox.Show("No hay conectados");
            }
            else
            {
                int trozo = Int32.Parse(trozos[i]);
                while (i < trozo - 1)
                {
                    n = dataGridView1.Rows.Add();
                    i++;
                }
            }
            for (i = 1; i < trozos.Length; i++)
            {
                dataGridView1.Rows[i - 1].Cells[0].Value = trozos[i];
            }
        }

        //Botón invitar conectados seleccionados
        private void button4_Click(object sender, EventArgs e)
        {
            //invitar a los jugadores seleccionados de la lista conectados y ver las respuestas de estos
        }

        //Botón Jugar
        private void button5_Click(object sender, EventArgs e)
        {
            Juego f4 = new Juego();
            //cargar dataGridView1 de f4 con los jugadores que han aceptado jugar a la partida
            f4.ShowDialog();
        }

        //Consulta las partidas ganadas por el usuario dado
        private void radioButton3_Click(object sender, EventArgs e)
        {
            string mensaje = "5/" + textBox1.Text;
            // Enviamos al servidor el user tecleado 
            byte[] msg = System.Text.Encoding.ASCII.GetBytes(mensaje);
            server.Send(msg);

            //Recibimos la respuesta del servidor
            byte[] msg2 = new byte[80];
            server.Receive(msg2);
            mensaje = Encoding.ASCII.GetString(msg2).Split('\0')[0];
            MessageBox.Show(mensaje);
        }

    }
}
